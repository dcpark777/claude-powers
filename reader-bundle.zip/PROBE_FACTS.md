# PROBE_FACTS — reader probes
# Fill: PASS / FAIL / SKIP + short note. Env codes: E1 Ghostty, E2 VSCode,
# E3 Windsurf, E4 Terminal/iTerm, E5 nested-tmux. One line per check;
# add "@E2: ..." suffixes only where an env differs from the rest.
# Paste this whole block back to Claude when done.

date:
cc_version:
tmux_version:

## Probe A — passthrough
A1_fidelity:
A2_interactivity:
A3_paste:
A4_resize:
A5_flip:
A6_repaint:          # note scrollback smear y/n, wiggles-needed count
A7_live_hidden:      # note any stall (terminal-query risk)
A8_esc_esc:          # total presses to interrupt
A9_clean_exit:
A10_key_reach:       # which keys survived E2/E3 (Ctrl+_ ? F12 ?)
A11_crash_couple:    # claude died with probe y/n
A12_scrollback:

exit_report:         # paste the probe's printed counter block here

## Probe B — tmux popup
B1_popup_over_pane:
B2_live_render:
B3_input_dismiss:
B4_restore:
B5_key_reach:
B6_nested_feel:      # subjective note, E2/E3

## Decision-rule readout (from RUNBOOK)
baseline:            # passthrough | tmux-required | undecided
default_key_candidate:
surprises:
