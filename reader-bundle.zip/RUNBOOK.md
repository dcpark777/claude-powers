# Reader Probe Runbook

Two probes, one decision: **can PTY passthrough be the universal baseline**
(tmux demoted to optional enhancement), or does tmux return as a requirement?

Record every check in `PROBE_FACTS.md` as `A1: PASS — <note>` / `FAIL — <note>`.
A finding is a finding either way; FAILs pick the architecture, they don't kill
the project.

## Environments

Run Probe A in each; run Probe B in the tmux-relevant ones.

| # | Environment                          | A | B |
|---|--------------------------------------|---|---|
| E1| Ghostty (daily driver)               | ✓ | ✓ |
| E2| VS Code integrated terminal          | ✓ | ✓ |
| E3| Windsurf integrated terminal         | ✓ | ✓ |
| E4| Terminal.app or iTerm2 (one of)      | ✓ | ✓ |
| E5| Inside an existing tmux session      | ✓ | – |

E5 exists to observe the nested case passthrough must tolerate and the
double-mux weirdness that justified demoting tmux.

## Expected probe artifacts — NOT findings

Quirks of the throwaway scripts. If you see these, don't log them as FAILs.

- **Bytes typed in the same chunk as the toggle are dropped.** Probe shortcut;
  the real sniffer buffers correctly.
- **A lone Esc pressed while a key sequence is mid-flight** can rarely
  misparse (the probe disambiguates by chunk length, not timing). The real
  input parser (crossterm) does this properly.
- **A11's `kill -9` leaves the terminal in raw mode** — the cleanup handler
  never runs. Type `reset` + Enter blind; that's expected.
- **Don't use `htop` as the stand-in for flip checks (A5–A8).** It owns the
  alternate screen itself and fights the probe's restore. Fine for A1-style
  relay checks; run flip checks against real `claude` (main-screen renderer).
- **Probe B's F12 binding is server-wide**, not session-scoped — it fires in
  every tmux session until `./popup_probe.sh clean`. The real tool scopes it.
- **F12 inside the popup won't close it** (popups capture input); use q/Esc.
  The real tool makes the toggle symmetric.

## Probe A — PTY passthrough (`passthrough_probe.py`)

Start: `python3 passthrough_probe.py` in a repo, use claude normally.
Toggle key: `Ctrl+_` (Ctrl+Shift+minus on most keyboards).

- **A1 Fidelity.** Claude Code under the probe is visually identical to naked
  `claude`: colors, spinner, box-drawing, no lag while streaming.
- **A2 Interactivity.** Slash-command autocomplete, arrow keys in a permission
  dialog, Tab, Ctrl+R history — all behave normally through the relay.
- **A3 Paste.** Paste a multi-line block into the prompt (bracketed paste).
  Arrives intact, no false toggle. (Known: a paste containing byte 0x1f WOULD
  false-trigger — probe limitation, real tool gets a paste-aware sniffer.)
- **A4 Resize.** Resize the window while Claude is streaming. CC reflows
  correctly (WINCH propagation works).
- **A5 Flip in/out.** Toggle to the dummy reader and back several times, idle
  and mid-stream. Screen restores; note any flicker and whether one wiggle
  repaint is always enough.
- **A6 Repaint quality.** After flip-back, CC's UI is complete — prompt box,
  status line, todo panel all redrawn, no half-frames. ALSO check scrollback
  above the live region: the cols−1→cols wiggle makes CC re-wrap, which could
  smear history. This is the load-bearing check; note any artifacts precisely.
- **A7 Live-while-hidden.** Give Claude a long task, flip to the reader, watch
  the drained-bytes counter climb. Confirms the tap sees output while hidden.
  ALSO watch for hangs: if CC emits a terminal query (cursor position etc.)
  while hidden, the probe drains it and nothing replies — a stall here is a
  low-probability, high-information finding (real tool would need to answer
  queries while hidden).
- **A8 Esc-Esc interrupt.** While Claude works: toggle to reader, press Esc
  (reader closes), press Esc again (Claude interrupts). Count total presses.
- **A9 Clean exit.** Exit claude normally under the probe. Terminal sane
  afterward (no raw-mode residue, cursor visible), findings report prints.
- **A10 Key reachability.** In E2/E3: does Ctrl+_ reach the probe, or does the
  IDE eat it? Try F12 too (`PROBE_TOGGLE=` won't help there — F12 is a
  multi-byte sequence the probe doesn't parse; just note whether the IDE
  intercepts it at all). This finding drives the default-keybind choice.
- **A11 Crash coupling.** From another terminal, `kill -9` the probe. Confirm
  claude dies with it. Expected and accepted — documents the isolation
  tradeoff vs tmux; the real relay loop must therefore be panic-proof.
- **A12 Scrollback.** In CC mode, host-terminal scrollback works natively.

## Probe B — tmux popup (`popup_probe.sh`)

Start: `./popup_probe.sh`, follow its printed instructions.

- **B1 Popup over live pane.** With claude running in the pane, F12 opens the
  dummy reader instantly; claude keeps working underneath.
- **B2 Live rendering.** The elapsed timer ticks — popup hosts a live TUI.
- **B3 Input + dismiss.** q and Esc close it; keystrokes go to the popup, not
  the pane. Reopen latency feels instant.
- **B4 Restore.** Pane redraws cleanly after close, no artifacts.
- **B5 Key reachability.** Same F12 question as A10, per environment.
- **B6 Nested feel (E2/E3).** Subjective: how weird is tmux-inside-IDE for a
  non-tmux user? This is adoption data, not a pass/fail.

## Decision rule

- A1–A9 all PASS in E1–E4 → **passthrough is the baseline**; tmux ships as
  optional enhancement (persistence/detach). Proceed to renderer spike.
- A5/A6 flaky (unreliable repaint) or A2 broken anywhere → tmux returns as
  the requirement; soften "any terminal" in the pitch; popup path from B wins.
- A10/B5 → whatever key survives VS Code/Windsurf becomes the shipped default;
  keybind configurable either way.
