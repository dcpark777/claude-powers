# READER — SPEC v0 (skeleton)

Status: pre-probe. Items marked ⧖A#/⧖B# are gated on PROBE_FACTS results.
Name: "reader" is a placeholder — naming pass happens at build start (per
portfolio sequencing), before any repo is created.

## 1. Identity

Terminal-native readability layer for Claude Code sessions. A CC session is
~10% typing, ~90% reading; this tool fixes the 90% and deliberately leaves
the 10% (CC's own input surface) untouched.

- v1 pitch: run `reader` instead of `claude`; one key flips between vanilla
  CC and a beautiful, live, read-only rendering of the session.
- Daily product: reading/review (live + after-the-fact). Share/export is a
  deferred feature, not the identity.
- README trust headline: reads local files only, zero network, zero
  telemetry, never writes to CC's stdin (reader mode), can't break a session.

## 2. Non-goals (permanent boundaries)

- No steering: reader mode never sends input to CC. Interrupt = Esc-Esc
  (flip back, then Esc lands in real CC). One-key interrupt is a *possible*
  future exception, deliberately unshipped in v1.
- No ANSI parsing/rewriting: CC's rendered output is relayed verbatim or
  drained; truth comes from JSONL only.
- No cross-session views: which-session-needs-me is Cosmo's lane. No session
  roster, ever.
- No orchestration: mission/crew's lane.
- No structural render customization (templates/plugins): themes + prefs only.
- No full CC frontend replacement; no feature-parity chase.

## 3. Architecture (layers)

- L0 Relay — PTY passthrough baseline ⧖A1–A9: pty owns `claude`, byte-
  verbatim both ways, alt-screen flip on toggle, WINCH-wiggle repaint on
  return ⧖A6. Relay loop must be panic-proof and minimal (crash coupling:
  wrapper death kills CC — accepted, mitigated by simplicity; renderer runs
  isolated so rendering bugs can't reach the relay). tmux detected at
  runtime = optional enhancement (persistence/detach; popup path ⧖B if
  passthrough fails its gate).
- L1 Data — consumed from strata (discovery, records, episodes, unified
  follow tail). Reader-specific event vocabulary is an open strata question
  (STRATA.md); resolve during Stage 5 entry. Unknown event types render as a
  graceful raw fold — never crash (schema churn is the maintenance tax).
- L2 Renderer — theme tokens + prefs consumed as data from the first widget
  (no hardcoded styles). Incremental parse, lazy render (multi-MB
  transcripts). Design contract: mockup v2 (DESIGN_mockup.html).
- L3 Entrypoints — v1: wrapper only. v1.1: `view <session>` (same renderer,
  file input). v1.1+: `log` (git-log for CC history). Later: export.

## 4. Mechanism decisions

- Toggle key: default chosen from ⧖A10/B5 findings (must survive VS Code +
  Windsurf interception); always configurable.
- Esc discrimination: real input parser (crossterm-style sequence timeouts),
  not the probe's chunk-length hack.
- Paste safety: bracketed-paste-aware toggle sniffer (probe limitation A3
  does not ship).
- Session binding (multi-session support): bind to the JSONL that
  appears/activates after spawn in cwd's project dir; disambiguate via
  process↔session mapping (Cosmo Phase 0 fact). Instances share nothing but
  read-only config.
- Title-as-status: OSC title = `● repo — working` / `◆ repo — needs you`
  (per-window; composes with Cosmo's roster, doesn't compete).
- Needs-you detection: CHECK_ME heuristic (process alive + transcript quiet
  + last-event shape). Banner ushers user to live pane; reader never renders
  the prompt content (it isn't on disk).
- Prose streaming: JSONL chunks, not tokens — "Claude is writing…" shimmer
  on the pending block. No closing this gap (would require ANSI tapping).
- Hidden-mode terminal queries ⧖A7: if CC stalls on unanswered queries while
  hidden, relay must answer them; otherwise drain-only stands.

## 5. Feature list (FROZEN — additions must displace something)

v1 core: wrapper, toggle overlay, live timeline (prompts/markdown/plan
checklist/collapsed tool rows/diffs/folded sidechains), follow mode,
Esc-Esc interrupt, needs-you banner + title-as-status + notification flag
(bell/OSC9) + waiting-on-you timer, per-step timings, header stats
(turns/tools/files/diffstat rollup/tokens/cost), n-p prompt jumps + g/G +
jump-to-last-diff, exit summary line, compaction + error markers,
slash-command labels on prompt blocks, y copy via OSC52.

v1.1: `view`, copy-as variants (patch / markdown / session-id),
open-in-editor from diff row, `log`, bookmarks (only if keybar allows;
keybar cap: 10).

Deferred (spec appendix, design parked): export — digest-first (deterministic
from JSONL: prompts, plan states, diffstats, durations, outcome; no code
bodies or tool outputs by default), progressive-disclosure HTML with opt-in
blocks chosen in a pre-export review; full-transcript export behind explicit
flag + secret-scan warning gate ("flags common secrets, cannot certify
absence"); digest one-keystroke, full deliberately not. Also deferred:
`--theme` + community themes directory (token seam ships in v1; themes as a
feature wait for an audience), optional `claude -p` digest polish.

## 6. Config

`~/.config/reader/config.toml`: keybind, theme (tokens: colors/glyphs/
borders), prefs (default collapse states, timestamp format, diff context,
density, notification on/off). Per-user by construction. Default theme =
mockup v2 palette; opinionated, screenshot-recognizable.

## 7. Open questions (resolve at Stage 5 entry)

- O1 Stack: strata is stdlib Python → Python/Textual consumes it natively
  but weakens the single-binary story; Rust/ratatui gives the binary but
  needs a strata bridge (capped JSON doors? port?). Decide after probe +
  strata v1 exists. Spike-in-Textual-first remains legitimate.
- O2 Toggle key default ⧖A10/B5.
- O3 Reader event vocabulary in strata (STRATA.md open question).
- O4 Name (before repo creation; check collisions — CrewAI lesson).
- O5 Repaint strategy if wiggle smears scrollback ⧖A6 (same-size nudge
  alternatives).

## 8. Sequencing

This project is Stage 5 of the portfolio campaign (MASTER_RUNBOOK): after
ccgrep Phase 0–1, lens probe, strata extraction, lens build. Probes may run
early in a shared probe evening; build starts only when Stage 4 completes.
One active build at a time.
