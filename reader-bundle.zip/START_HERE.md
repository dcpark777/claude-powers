# START_HERE — reader bundle (agent-facing)

You are Claude Code on Dan's work machine. This bundle is the complete
current state of the READER project (portfolio Stage 5). Guide Dan through
the probes; if they pass, this bundle contains enough to continue toward the
build — but respect the stop gates.

## Bundle contents

- passthrough_probe.py — Probe A (PTY relay). Stdlib-only. Emits AUTO
  PASS/FAIL lines + post-run quiz; appends everything to probe_results.txt.
- popup_probe.sh — Probe B (tmux popup). `report` mode emits B-check lines
  to the same probe_results.txt.
- RUNBOOK.md — env matrix, artifacts-vs-findings, checks A1–A12 / B1–B6,
  DECISION RULE (read it before judging anything).
- PROBE_FACTS.md — relay template (probe_results.txt now pre-fills most of
  it; consolidate results per environment into this file).
- SPEC.md — v0 skeleton; every ⧖ marker is a probe-gated decision.
- DESIGN_mockup.html — the design contract; open in a browser.

## State detection (idempotent re-entry)

| Observed | State | Action |
|---|---|---|
| no probe_results.txt | probes not run | Stage P below |
| probe_results.txt, PROBE_FACTS incomplete | mid-probe | consolidate, resume matrix |
| PROBE_FACTS complete, baseline undecided | judgment | apply RUNBOOK decision rule with Dan |
| baseline decided | gate | STOP GATE 2, then pre-build tasks only |

## Stage P — probes

1. Dan runs Probe A per RUNBOOK in each environment (E1–E5); quiz after each
   run; env code added by hand to each block in probe_results.txt.
2. Probe B in tmux-relevant envs; `./popup_probe.sh report` after; `clean`
   when done.
3. Consolidate probe_results.txt → PROBE_FACTS.md (one verdict per check,
   @Ex suffixes where environments differ).
4. Apply the RUNBOOK decision rule. Record `baseline:` in PROBE_FACTS.md.
5. Relay PROBE_FACTS.md back to chat-Claude (paste) for SPEC v1.

## STOP GATES

- GATE 1 (before anything beyond probes): confirm portfolio Stage 4 (lens
  build on strata) is complete. If not, STOP after Stage P — reader build
  does not start early; one active build at a time.
- GATE 2 (before repo creation): naming pass with Dan (SPEC O4); Dan
  approves name + repo location explicitly.
- GATE 3 (before writing renderer code): resolve SPEC O1 (stack) and O3
  (strata reader vocabulary) with Dan — these are decisions, not defaults.

## Pre-build tasks allowed once probes PASS and Gate 1 holds

- Resolve SPEC ⧖ markers from PROBE_FACTS (toggle key default, repaint
  strategy, passthrough-vs-tmux baseline) — edit SPEC.md in place.
- Draft the renderer spike plan: one real saved session → rendered timeline,
  theme tokens as data from the first widget, incremental parse.
- Nothing else. No repo, no code beyond the spike plan, until gates clear.

## Failure paths

- A6/A5 flaky (repaint unreliable) → tmux returns as requirement; popup path
  is the mechanism; soften "any terminal" in SPEC §1; note in PROBE_FACTS.
- A2 broken anywhere → passthrough dead in that env; document which.
- A7 stall observed → add query-answering to L0 scope (SPEC §4 last bullet).
- Key findings (A10/B5) are never failures — they pick the default.
