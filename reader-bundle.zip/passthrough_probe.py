#!/usr/bin/env python3
"""passthrough_probe.py — Probe A: PTY passthrough feasibility.

Tests the reader's proposed baseline mechanism WITHOUT any reader code:
  1. Run `claude` (or any TUI) under a PTY we own, relaying bytes verbatim.
  2. On a toggle key, stop painting the child and show a dummy "reader"
     on the alternate screen (child keeps running; its output is drained).
  3. On flip-back, restore the screen and force the child to repaint via
     a WINCH size-wiggle.

Stdlib only. No parsing, no rewriting — pure byte relay.

Usage:
    python3 passthrough_probe.py                 # runs `claude`
    python3 passthrough_probe.py -- htop         # any TUI as stand-in
    PROBE_TOGGLE=0x14 python3 passthrough_probe.py   # override toggle byte

Default toggle: Ctrl+_ (0x1f). In the dummy reader:
    Ctrl+_ or q  -> flip back to the child
    Esc          -> flip back (so Esc-Esc = interrupt claude, check A8)

Known probe limitation (by design, see RUNBOOK A3): the toggle byte is
sniffed anywhere in the input stream, so a paste containing 0x1f would
false-trigger. The real tool gets a bracketed-paste-aware sniffer.
"""

import errno
import fcntl
import os
import pty
import select
import signal
import struct
import sys
import termios
import time
import tty

TOGGLE = int(os.environ.get("PROBE_TOGGLE", "0x1f"), 16)
ESC = 0x1B

STDIN = 0
STDOUT = 1

stats = {
    "bytes_child_to_screen": 0,
    "bytes_drained_hidden": 0,
    "bytes_user_to_child": 0,
    "toggles": 0,
    "winches": 0,
    "wiggles": 0,
    "started": time.time(),
}

winch_pending = [False]


def get_winsize(fd):
    data = fcntl.ioctl(fd, termios.TIOCGWINSZ, b"\x00" * 8)
    rows, cols, xp, yp = struct.unpack("HHHH", data)
    return rows, cols


def set_winsize(fd, rows, cols):
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))


def on_winch(signum, frame):
    winch_pending[0] = True
    stats["winches"] += 1


def wiggle(master_fd):
    """Force the child to repaint by briefly changing its winsize."""
    rows, cols = get_winsize(STDIN)
    set_winsize(master_fd, rows, cols - 1)
    time.sleep(0.03)
    set_winsize(master_fd, rows, cols)
    stats["wiggles"] += 1


def draw_reader(tail, drained):
    rows, cols = get_winsize(STDIN)
    w = min(cols, 78)
    out = []
    out.append("\x1b[2J\x1b[H")  # clear alt screen, home
    bar = "─" * (w - 2)
    out.append(f"\x1b[36m┌{bar}┐\x1b[0m\r\n")
    title = " DUMMY READER — child still running underneath "
    out.append(f"\x1b[36m│\x1b[0m\x1b[1m{title:<{w-2}}\x1b[0m\x1b[36m│\x1b[0m\r\n")
    out.append(f"\x1b[36m├{bar}┤\x1b[0m\r\n")
    lines = [
        "",
        f"  bytes drained while hidden : {drained}",
        f"  toggles so far            : {stats['toggles']}",
        f"  elapsed                   : {time.time() - stats['started']:.0f}s",
        "",
        "  If the drained counter grows while Claude is working,",
        "  live-updates-while-hidden is CONFIRMED (check A7).",
        "",
        "  keys:  Ctrl+_ / q  -> back to child",
        "         Esc         -> back to child (then Esc again = interrupt)",
        "",
        "  last 120 raw bytes from child (proves the tap sees output):",
        "  " + repr(tail[-120:])[:w - 6],
        "",
    ]
    for ln in lines:
        out.append(f"\x1b[36m│\x1b[0m{ln:<{w-2}}\x1b[36m│\x1b[0m\r\n")
    out.append(f"\x1b[36m└{bar}┘\x1b[0m\r\n")
    os.write(STDOUT, "".join(out).encode())


RESULTS_FILE = "probe_results.txt"

A_CHECKS = [
    ("A1_fidelity", "CC visually identical to naked claude, no lag"),
    ("A2_interactivity", "autocomplete/arrows/dialogs behave normally"),
    ("A3_paste", "multi-line bracketed paste arrives intact"),
    ("A4_resize", "CC reflows correctly on window resize"),
    ("A5_flip", "toggle in/out restores screen"),
    ("A6_repaint", "full repaint after flip-back; NOTE scrollback smear + wiggle count"),
    ("A7_live_hidden", "drained counter climbs; NOTE any stall"),
    ("A8_esc_esc", "Esc-Esc interrupts claude; NOTE press count"),
    ("A9_clean_exit", "terminal sane after claude exits"),
    ("A10_key_reach", "NOTE which keys survive VS Code/Windsurf"),
    ("A11_crash_couple", "kill -9 probe -> claude died too (expected)"),
    ("A12_scrollback", "host-terminal scrollback works in CC mode"),
]


def auto_lines():
    lines = []

    def emit(key, ok, skip=False, note=""):
        verdict = "SKIP" if skip else ("PASS" if ok else "FAIL")
        lines.append(f"AUTO {key}: {verdict}" + (f" — {note}" if note else ""))

    emit("relay_child_to_screen", stats["bytes_child_to_screen"] > 0,
         note=f"{stats['bytes_child_to_screen']} bytes")
    emit("relay_user_to_child", stats["bytes_user_to_child"] > 0,
         note=f"{stats['bytes_user_to_child']} bytes")
    toggled = stats["toggles"] > 0
    emit("drain_while_hidden", stats["bytes_drained_hidden"] > 0, skip=not toggled,
         note=f"{stats['bytes_drained_hidden']} bytes over {stats['toggles']} toggles")
    emit("winch_propagation", stats["winches"] > 0, skip=stats["winches"] == 0,
         note=f"{stats['winches']} winches, {stats['wiggles']} wiggles")
    emit("relay_loop_survived", True)
    return lines


def quiz():
    """Interactive post-run checklist -> relay-ready single-liners."""
    print("\npost-run checklist — p=pass f=fail s/Enter=skip, then optional note")
    out = []
    for key, desc in A_CHECKS:
        try:
            ans = input(f"  {key} ({desc}) [p/f/s]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("  (quiz aborted)")
            break
        if ans not in ("p", "f"):
            out.append(f"{key}: SKIP")
            continue
        note = input("    note (Enter for none): ").strip()
        verdict = "PASS" if ans == "p" else "FAIL"
        out.append(f"{key}: {verdict}" + (f" — {note}" if note else ""))
    return out


def report():
    dur = time.time() - stats["started"]
    print("\n──── passthrough probe results " + "─" * 31)
    autos = auto_lines()
    for ln in autos:
        print("  " + ln)
    print(f"  AUTO duration_s: {dur:.0f}")

    quizzed = []
    if sys.stdin.isatty() and os.environ.get("PROBE_NO_QUIZ") != "1":
        quizzed = quiz()
        for ln in quizzed:
            print("  " + ln)
    else:
        print("  (quiz skipped — non-tty or PROBE_NO_QUIZ=1; fill PROBE_FACTS.md by hand)")

    try:
        with open(RESULTS_FILE, "a") as f:
            f.write(f"\n# passthrough run {time.strftime('%Y-%m-%d %H:%M')} "
                    f"(fill env code by hand)\n")
            for ln in autos + [f"AUTO duration_s: {dur:.0f}"] + quizzed:
                f.write(ln + "\n")
        print(f"  written to ./{RESULTS_FILE} — paste that block back")
    except OSError as e:
        print(f"  (could not write {RESULTS_FILE}: {e})")
    print("─" * 62)


def main():
    if not sys.stdin.isatty():
        sys.exit("passthrough_probe: needs a real terminal (stdin is not a tty)")
    args = sys.argv[1:]
    if args and args[0] == "--":
        args = args[1:]
    cmd = args if args else ["claude"]

    pid, master = pty.fork()
    if pid == 0:  # child
        os.execvp(cmd[0], cmd)

    old_attrs = termios.tcgetattr(STDIN)
    signal.signal(signal.SIGWINCH, on_winch)
    rows, cols = get_winsize(STDIN)
    set_winsize(master, rows, cols)

    in_reader = False
    tail = b""
    drained_this_flip = 0
    exit_reason = "unknown"

    try:
        tty.setraw(STDIN)
        while True:
            if winch_pending[0]:
                winch_pending[0] = False
                r, c = get_winsize(STDIN)
                set_winsize(master, r, c)  # kernel signals child itself
                if in_reader:
                    draw_reader(tail, drained_this_flip)

            timeout = 0.5 if in_reader else None
            try:
                ready, _, _ = select.select([STDIN, master], [], [], timeout)
            except InterruptedError:
                continue

            if in_reader and not ready:
                draw_reader(tail, drained_this_flip)  # tick refresh

            if master in ready:
                try:
                    data = os.read(master, 65536)
                except OSError as e:
                    if e.errno == errno.EIO:
                        data = b""
                    else:
                        raise
                if not data:
                    exit_reason = "child exited"
                    break
                tail = (tail + data)[-512:]
                if in_reader:
                    stats["bytes_drained_hidden"] += len(data)
                    drained_this_flip += len(data)
                    draw_reader(tail, drained_this_flip)
                else:
                    stats["bytes_child_to_screen"] += len(data)
                    os.write(STDOUT, data)

            if STDIN in ready:
                data = os.read(STDIN, 65536)
                if not data:
                    exit_reason = "stdin closed"
                    break
                if not in_reader:
                    if TOGGLE in data:
                        pre, _, post = data.partition(bytes([TOGGLE]))
                        if pre:
                            os.write(master, pre)
                            stats["bytes_user_to_child"] += len(pre)
                        # NOTE: bytes after the toggle in the same chunk are
                        # dropped — acceptable for a probe, noted in RUNBOOK.
                        in_reader = True
                        stats["toggles"] += 1
                        drained_this_flip = 0
                        os.write(STDOUT, b"\x1b[?1049h")  # enter alt screen
                        draw_reader(tail, drained_this_flip)
                    else:
                        os.write(master, data)
                        stats["bytes_user_to_child"] += len(data)
                else:
                    # Arrow/function keys and mouse events arrive as multi-byte
                    # ESC-prefixed sequences; only a LONE 0x1b is a real Esc.
                    # Crude (a real input parser uses sequence timeouts) but
                    # kills the worst probe artifact.
                    lone_esc = data == bytes([ESC])
                    if TOGGLE in data or b"q" in data or lone_esc:
                        in_reader = False
                        os.write(STDOUT, b"\x1b[?1049l")  # leave alt screen
                        wiggle(master)  # force child repaint
                    # all other keys (incl. escape sequences) ignored here
    finally:
        termios.tcsetattr(STDIN, termios.TCSADRAIN, old_attrs)
        try:
            os.kill(pid, signal.SIGHUP)
        except ProcessLookupError:
            pass
        try:
            os.waitpid(pid, os.WNOHANG)
        except ChildProcessError:
            pass
        report()
        print(f"exit: {exit_reason}")


if __name__ == "__main__":
    main()
