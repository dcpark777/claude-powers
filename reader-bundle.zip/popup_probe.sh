#!/usr/bin/env bash
# popup_probe.sh — Probe B: tmux popup mechanics (the fallback/enhancement path).
#
# Verifies that `tmux display-popup` can host a long-running interactive TUI,
# toggled by a session-scoped keybind, over a live claude pane.
#
# Usage:
#   ./popup_probe.sh          # inside OR outside tmux; sets everything up
#   ./popup_probe.sh report   # post-run questionnaire -> PASS/FAIL one-liners
#   ./popup_probe.sh clean    # remove binding + temp files
#
# Toggle key: F12 (change TOGGLE_KEY below if your terminal eats F12 —
# that itself is a RUNBOOK finding, B5).

set -euo pipefail

TOGGLE_KEY="F12"
DUMMY=/tmp/popup_dummy.py
SESSION="probe-popup"

if [[ "${1:-}" == "clean" ]]; then
  tmux unbind-key -n "$TOGGLE_KEY" 2>/dev/null || true
  rm -f "$DUMMY"
  echo "cleaned: unbound $TOGGLE_KEY, removed $DUMMY"
  exit 0
fi

if [[ "${1:-}" == "report" ]]; then
  RESULTS=probe_results.txt
  echo "# popup run $(date '+%Y-%m-%d %H:%M') (fill env code by hand)" >> "$RESULTS"
  declare -a CHECKS=(
    "B1_popup_over_pane|popup opens instantly over live claude pane"
    "B2_live_render|elapsed timer ticks inside popup"
    "B3_input_dismiss|q/Esc close it; keys go to popup not pane"
    "B4_restore|pane redraws cleanly after close"
    "B5_key_reach|NOTE which keys survive VS Code/Windsurf"
    "B6_nested_feel|subjective: tmux-in-IDE weirdness (note only)"
  )
  echo "p=pass f=fail s/Enter=skip, then optional note"
  for entry in "${CHECKS[@]}"; do
    key="${entry%%|*}"; desc="${entry#*|}"
    read -r -p "  $key ($desc) [p/f/s]: " ans || break
    case "$ans" in
      p|P) verdict="PASS";;
      f|F) verdict="FAIL";;
      *)   echo "$key: SKIP" | tee -a "$RESULTS"; continue;;
    esac
    read -r -p "    note (Enter for none): " note || note=""
    line="$key: $verdict"; [[ -n "$note" ]] && line="$line — $note"
    echo "$line" | tee -a "$RESULTS"
  done
  echo "written to ./$RESULTS — paste that block back"
  exit 0
fi

command -v tmux >/dev/null || { echo "FAIL: tmux not installed"; exit 1; }
echo "tmux version: $(tmux -V)   (need >= 3.2 for display-popup)"

# ── dummy popup TUI ─────────────────────────────────────────────────────
cat > "$DUMMY" <<'PYEOF'
#!/usr/bin/env python3
import os, select, sys, termios, time, tty

fd = sys.stdin.fileno()
old = termios.tcgetattr(fd)
start = time.time()
try:
    tty.setraw(fd)
    while True:
        cols = os.get_terminal_size().columns
        bar = "─" * min(cols - 2, 76)
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.write(f"\x1b[36m┌{bar}┐\x1b[0m\r\n")
        sys.stdout.write("\x1b[36m│\x1b[0m \x1b[1mDUMMY READER (tmux popup)\x1b[0m\r\n")
        sys.stdout.write(f"\x1b[36m│\x1b[0m elapsed: {time.time()-start:5.1f}s  "
                         "(ticking = popup renders live)\r\n")
        sys.stdout.write("\x1b[36m│\x1b[0m keys: q or Esc closes the popup\r\n")
        sys.stdout.write(f"\x1b[36m└{bar}┘\x1b[0m\r\n")
        sys.stdout.flush()
        r, _, _ = select.select([fd], [], [], 0.2)
        if r:
            ch = os.read(fd, 16)
            if b"q" in ch or b"\x1b" in ch:
                break
finally:
    termios.tcsetattr(fd, termios.TCSADRAIN, old)
PYEOF
chmod +x "$DUMMY"

# ── binding: toggle behavior — open if closed; popups close via q/Esc ──
tmux bind-key -n "$TOGGLE_KEY" display-popup -E -w 95% -h 90% "python3 $DUMMY" \
  2>/dev/null || {
    echo "note: no tmux server yet; binding will be set after session start"
  }

if [[ -z "${TMUX:-}" ]]; then
  echo "starting detached session '$SESSION' running your shell…"
  tmux new-session -d -s "$SESSION" 2>/dev/null || true
  tmux bind-key -n "$TOGGLE_KEY" display-popup -E -w 95% -h 90% "python3 $DUMMY"
  echo
  echo "next:  tmux attach -t $SESSION"
  echo "then:  run 'claude' in the pane, press $TOGGLE_KEY over it (checks B1-B4)"
else
  tmux bind-key -n "$TOGGLE_KEY" display-popup -E -w 95% -h 90% "python3 $DUMMY"
  echo "binding set in current tmux server."
  echo "run 'claude' in this pane, press $TOGGLE_KEY over it (checks B1-B4)"
fi
echo "when done: ./popup_probe.sh clean"
